#!/bin/bash

echo "🔧 Updating system packages..."
sudo apt update && sudo apt upgrade -y

echo "🐍 Installing Python 3, pip, and development headers..."
sudo apt install -y python3 python3-pip python3-dev build-essential libyara-dev libfuzzy-dev

echo "📦 Installing yara and tkinter dependencies..."
sudo apt install -y yara yara-doc python3-tk

echo "📁 Creating Python virtual environment (optional)..."
python3 -m venv pdfscan-env
source pdfscan-env/bin/activate

echo "📜 Installing Python packages..."
pip install --upgrade pip
pip install -r requirements.txt

echo "✅ Installation complete. Run the scanner with:"
echo "source pdfscan-env/bin/activate && python3 part2.py"
